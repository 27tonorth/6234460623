/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab4_3;

import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class TimeIntervalTester {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int startTime = scan.nextInt();
        System.out.print("Enter end time: ");
        int endTime = scan.nextInt();
        TimeInterval test = new TimeInterval(startTime,endTime);
        System.out.printf("%d hours %d minutes%n",test.getHours(),test.getMinutes());
    }
    
}
