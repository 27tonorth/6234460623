/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_2;

/**
 *
 * @author usci
 */
public class DigitExtractor {
    public int num = 0;
    public int cnt = 1;
    public DigitExtractor(int anInteger) 
    {
        num = anInteger;
    }
    public int nextDigit() 
    {
        int a = (int) (num % Math.pow(10,cnt) / Math.pow(10,cnt-1));
        cnt = cnt+1;
        return (a);
    }  
}