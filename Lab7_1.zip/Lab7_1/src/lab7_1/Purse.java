/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

/**
 *
 * @author usci
 */
import java.util.ArrayList;
public class Purse {
    private final ArrayList<String> wallet=new ArrayList();
    private final ArrayList<String> rev_wallet = new ArrayList();
    public void addCoin(String coinName){
        wallet.add(coinName);
    }
    @Override
    public String toString() {
        return "Purse"+wallet;
    }
    public int size(){
        return wallet.size();
    }
    
    public String get(int i){
        return wallet.get(i);
    }
    public ArrayList<String> reverse(){
        for(int i=wallet.size()-1;i>=0;i--){
            rev_wallet.add(wallet.get(i));
        }
        return rev_wallet;
    }
    public void transfer(Purse other){
        for(int i=0;i<wallet.size();i++){
            other.addCoin(wallet.get(i));
        }

        for(int i=0;i<wallet.size()+3;i++){
            wallet.remove(0);
        }
    }
    public boolean sameContents(Purse other){
        int same =0;
        if(wallet.size()!=other.size()){
            return false;
        }
        else{
            for(int i=0;i<wallet.size();i++){
                if(wallet.get(i)==other.get(i)){
                    same+=1;
                }
                else{
                    same-=1;
                }
            }
            return same == wallet.size();
        }
    }

    public boolean sameCoins(Purse other){
        int coin1=0;
        int coin2=0;
        if(wallet.size()!=other.size()){
            return false;
        }
        else{
            for(int i=0;i<wallet.size();i++){
                switch(other.get(i)){
                    case "Quater":{coin1+=1;}
                    case "Dime":{coin1+=1;}
                    case "Nickel":{coin1+=1;}
                    case "Penny": {coin1+=1;}
                }
                switch(wallet.get(i)){
                    case "Quater":{coin2+=1;}
                    case "Dime":{coin2+=1;}
                    case "Nickel":{coin2+=1;}
                    case "Penny": {coin2+=1;}
                }
            }
            return coin1==coin2;
        }
    }
}
