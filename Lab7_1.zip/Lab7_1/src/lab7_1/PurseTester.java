/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

/**
 *
 * @author usci
 */
public class PurseTester {
    public static void main(String[] args) {
        Purse p1 = new Purse();
        Purse p2 = new Purse();
        p1.addCoin("Dime");
        p1.addCoin("Dime");
        p1.addCoin("Penny");
        p1.addCoin("Quater");
        
        p2.addCoin("Dime");
        p2.addCoin("Dime");
        p2.addCoin("Penny");
        p2.addCoin("Quater");
        System.out.println(p1.sameContents(p2));
    }

    
}
