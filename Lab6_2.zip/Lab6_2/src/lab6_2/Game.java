/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_2;

/**
 *
 * @author usci
 */
import java.util.Scanner;
import java.util.Random;
public class Game {
    private int comWin;
    private int userWin;
    public void Game() 
    {
        comWin = 0;
        userWin = 0;
    }
    public void play() 
    {
        while(true) {
            Scanner in = new Scanner(System.in);
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            String userChoose = in.next();
            if (null != userChoose) switch (userChoose) {
                case "0":
                    System.out.println("You enter: ROCK");
                    break;
                case "1":
                    System.out.println("You enter: PAPER");
                    break;
                case "2":
                    System.out.println("You enter: SCISSORS");
                    break;
                default:
                    continue;
            }
            Random comPlay = new Random();
            int comChoose = comPlay.nextInt(3);
            if (comChoose==0) {
                System.out.println("Computer: ROCK");
            }
            if (comChoose==1) {
                System.out.println("Computer: PAPER");
            }
            if (comChoose==2) {
                System.out.println("Computer: SCISSORS");
            }
            int choose = Integer.parseInt(userChoose);
            if ((choose == 0 && comChoose == 2) || (choose == 1 && comChoose == 0) || (choose == 2 && comChoose == 1)) {
                System.out.println("You win!");
                userWin+=1;
            }
            if ((choose == 0 && comChoose == 0) || (choose == 1 && comChoose == 1) || (choose == 2 && comChoose == 2)) {
                System.out.println("It's a tie.");
            }
            if ((choose == 0 && comChoose == 1) || (choose == 1 && comChoose == 2) || (choose == 2 && comChoose == 0)) {
                System.out.println("You lose!");
                comWin+=1;
            }
           
            if(comWin-userWin==2) {
                System.out.println("----------------------------------------");
                System.out.println("Too bad! You lose.");
                System.out.println("User Score: "+userWin);
                System.out.println("Computer Score: "+comWin);
                break;
            }
            if(userWin-comWin==2) {
                System.out.println("----------------------------------------");
                System.out.println("Congrats! You win.");
                System.out.println("User Score: "+userWin);
                System.out.println("Computer Score: "+comWin);
                break;
            }
        }
    }  
}