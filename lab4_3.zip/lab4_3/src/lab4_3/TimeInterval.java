/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author Acer
 */
public class TimeInterval {
    private int startTime = 0;
    private int endTime = 0;
    private int start = 0;
    private int end = 0;
    public TimeInterval(int timeStart, int timeEnd)
    {
        startTime = timeStart;
        endTime = timeEnd;
        
        int startHr = 0;
        startHr = timeStart/100;
        int startMin = 0;
        startMin = timeStart%100;
        int endHr = 0;
        endHr = timeEnd/100;
        int endMin = 0;
        endMin = timeEnd%100;
                
        end = endMin + (endHr*60);
        start = startMin + (startHr*60);
    }
    
    public int getHours()
    {
        return((int) ((end-start)/60));
    }
    
    public int getMinutes()
    {
        return((end-start)%60);      
    }
}
