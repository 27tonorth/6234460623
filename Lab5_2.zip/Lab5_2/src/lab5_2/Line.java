/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;

import java.awt.geom.Point2D;
import static java.lang.Double.NaN;

/**
 *
 * @author Acer
 */
public class Line {
    private double m;
    private double b;
    private double x;
    
    public Line(double x, double y, double m)
    {
        this.m=m;
        b=y-(m*x);
        this.x=NaN;
    }
    public Line(double x1, double y1, double x2, double y2) 
    {
        m=(y2-y1)/(x2-x1);
        b=y1-(m*x1);
        this.x=NaN;
    }
    public Line(double m, double b) 
    {
        this.m=m; 
        this.b=b;
        x=NaN;
    }
    public Line(double a)
    {
        m=NaN;
        b=NaN;
        x=a;
    }
    public boolean isParallel(Line line){
        return (this.m==line.m);
    }
    public boolean equals(Line line){
        return (this.m==line.m && this.b==line.b);
    }
    public boolean isIntersect(Line line){
        return (this.m!=line.m);
    }
    public Point2D.Double getIntersectionPoint(Line line){
        double x,y;
        if (Double.isNaN(this.m)){
            x = this.x;
            y = line.m*x+line.b;
        }
        else if (Double.isNaN(line.m)){
            x = line.x;
            y = this.m*x+this.b;
        }
        else{
            x = (line.b-this.b)/(this.m-line.m);
            y = this.m*x+this.b;
        }
        return new Point2D.Double(x,y);
    }    
}
