/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class SequentialText {

    public static void main(String[] args) throws FileNotFoundException {
        
        System.out.println("*You may now start typing (type quit to exit)*");
        
        String str = "";
        Scanner sc = new Scanner(System.in);
        int charCnt = 0;
        int wordCnt = 0;
        int lineCnt = 0;
        
        boolean firstLine = true;
        
        while (true) {
            String line = sc.nextLine();
            if(line.equals("quit")){
                break;
            }
            if(firstLine){
                str += line;
                firstLine = false;
            }else{
                str += "\n";
                str += line;
            }
        }
            
        File file = new File("output.txt");
        PrintWriter output = new PrintWriter(file);
        output.print(str);
        output.close();

        Scanner read = new Scanner(file);
        while (read.hasNextLine()) {
            String line = read.nextLine();
            lineCnt++;
            charCnt = charCnt + line.length();
            String[] words = line.split(" ");
            wordCnt = wordCnt + words.length; 
        }    
        System.out.print("Total characters : ");
        System.out.println(charCnt);
        System.out.print("Total words : ");
        System.out.println(wordCnt);
        System.out.print("Total lines : ");
        System.out.println(lineCnt);
            
        }
        
}
    