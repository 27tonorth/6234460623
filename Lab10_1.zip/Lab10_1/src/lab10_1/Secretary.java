/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;

/**
 *
 * @author Acer
 */
public class Secretary extends Employee implements Evaluation {
    private int typingSpeed;
    private int score[];
    private char grade;
    
    public Secretary(String name,int salary,int score[],int typingSpeed){
        super(name,salary);
        this.score = score;
        this.typingSpeed = typingSpeed;
        
    }
    @Override
    public double evaluate(){
        int total = 0;
        for (int i=0;i<score.length;i++){
            total = total+score[i];
        }
        return total;
    }
    
    @Override
    public char grade(double total){
        if (total>=90){
            setSalary(18000);
            grade = 'P';
        }
        else{
            grade = 'F' ;
        }
        return grade;
    }
}
