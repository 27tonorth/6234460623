/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3.pkg2;

/**
 *
 * @author usci
 */
public class Letter {
    private String from;
    private String to;
    private String letter;
    public Letter(String from, String to){
        this.from=from;
        this.to=to;
        letter="";
    }
    public void addLine(String line){
            letter = letter + "\n" +line;
        }
    public String getText(){
            return("Dear "+to+"\n"+letter+"\n\nSincerely\n\n"+from);
        } 
}
