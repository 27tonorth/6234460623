package com.example.lab4_4;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    static String theYear, easterDay;
    private  EditText easterdd;
    private Button check;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        easterdd = findViewById(R.id.year);
        check = findViewById(R.id.enter);

        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                theYear = easterdd.getText().toString();

                if(theYear.length()!=0) {
                    int num = Integer.parseInt(theYear);

                    Easter easter = new Easter(num);
                    easterDay = easter.examine();
                    startActivity(new Intent(MainActivity.this, ShowResult.class));
                }

            }
        });


    }
}
