/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_3;

/**
 *
 * @author Acer
 */
public class TransactionRecord {
    
    private int acctNo;
    private double balance;
    private int transCnt;

    public TransactionRecord(int acctNo, double balance) {
        this.acctNo = acctNo;
        this.balance = balance;
        this.transCnt = 1;
    }

    public int getAcctNo() {
        return acctNo;
    }

    public void setAcctNo(int acctNo) {
        this.acctNo = acctNo;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public int getTransCnt() {
        return transCnt;
    }

    public void setTransCnt(int transCnt) {
        this.transCnt = transCnt;
    }

    @Override
    public String toString() {
        return "TransactionRecord{" +
                "acctNo=" + acctNo +
                ", balance=" + balance +
                ", transCnt=" + transCnt +
                '}';
    }
    
}
