/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3.pkg3;

/**
 *
 * @author Acer
 */
public class CashRegister {
    private double purchase;
    private double tax;
    private double payment;
    private double totalTax;
    public CashRegister(double num)
    {
        purchase = 0;
        payment = 0;
        tax = num;
        totalTax = 0;
    }
    public void recordPurchase(double amount)
    {
        purchase = purchase+amount;
    }
    public void recordTaxablePurchase(double amount)
    {
        purchase = purchase+amount;
        totalTax = totalTax+amount*(tax/100);
    }
    public void enterPayment(double amount)
    {
        payment = payment+amount;
    }
    public double getTotalTax(){
        return totalTax;
    }
    public double giveChange(){
        double change = payment - purchase - totalTax;
        payment = 0;
        purchase = 0;
        return change;
    }
}
