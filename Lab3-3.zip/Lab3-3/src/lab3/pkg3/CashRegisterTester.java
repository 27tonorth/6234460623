/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3.pkg3;

/**
 *
 * @author Acer
 */
public class CashRegisterTester {
    public static void main(String[] args){
        CashRegister ex = new CashRegister(7);
        ex.recordPurchase(50);
        ex.recordPurchase(10);
        ex.recordTaxablePurchase(20);
        ex.enterPayment(100);
        System.out.println("Your change is "+ex.giveChange());
    }
}
