/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_1;

import java.util.ArrayList;

/**
 *
 * @author Acer
 */
public class Order {
    public static int cntOrder = 0;  
    private int id;     
    private Customer c;     
    private ArrayList<Pizza> p = new ArrayList<Pizza>(); 
     
    public Order(Customer c){
        this.c = c;
        cntOrder++;
    }
    
    public void addPizza(Pizza pizza){
        p.add(pizza);
    }
    
    public String getOrderDetail(){
        String detail = "Order id : " + cntOrder + "\n";
        detail += c.toString() + "\n";
        for (Pizza pi : p){
            detail += pi.toString() + "\n";
        }
        detail += "Total pieces : " + p.size() + "\n";
        detail += "Total cost : " + this.calculatePayment();
        
        return detail;
    }
    
    public double calculatePayment(){
        double totalPrice = 0;
        double discount = 0;
        if(c instanceof GoldCustomer){
           GoldCustomer gc = (GoldCustomer) c;
           discount = gc.getDiscount();
        }
        
        for(Pizza pi : p)
            totalPrice += pi.getPrice();
        
        double total = totalPrice*((100-discount)/100);
        return total;
    }
}
